package com.likelion.moamoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoamoaApplicationTests {

	@Test
	void contextLoads() {
	}

}

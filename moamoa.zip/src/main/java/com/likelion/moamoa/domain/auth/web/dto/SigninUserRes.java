package com.likelion.moamoa.domain.auth.web.dto;

public record SigninUserRes(String loginId) {
}

package com.likelion.moamoa.domain.auth.web.dto;

public record SignupUserRes(Long userId) {
}

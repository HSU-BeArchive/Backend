package com.likelion.moamoa.common.chat.entitiy;

public enum MessageRole {
    USER,AI
}

//package com.likelion.moamoa.common.chat.exception;
//
//import com.likelion.moamoa.global.exception.BaseException;
//
//public class ForbiddenRecommendationException extends BaseException {
//    public ForbiddenRecommendationException() {
//        super(ChatErrorCode.RECOMMENDATION_FORBIDDEN_403);
//    }
//}

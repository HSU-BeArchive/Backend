package com.likelion.moamoa.common.question.service;

public interface OpenAiService {
    String getRecommendationQuestion(String imgUrl,String description);
}
